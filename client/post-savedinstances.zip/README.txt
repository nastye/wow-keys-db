extract archive into subfolder of your accounts savedvariables folder
i.e. D:\games\World of Warcraft\_retail_\WTF\Account\401500458#1\SavedVariables\post-savedinstances
right click install.bat, run as administrator
hope keys show up on keys.nastye.xyz